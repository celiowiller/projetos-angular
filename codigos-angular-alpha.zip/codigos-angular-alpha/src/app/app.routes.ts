// abaixo, estamos importando o recurso necessario para criar rotas que serão 
// estabelecidas para a nagevação entre componentes
import { Routes } from '@angular/router';
import { InterpolationComponent } from './componentes/interpolation/interpolation.component';
import { PBindingComponent } from './componentes/p-binding/p-binding.component';


export const routes: Routes = [
    // aqui, serão compostas/estabelecidas cada uma das rotas que "apontam" para cada um  dos componentes do projeto

    // localhost:4200/interpolation
    {path: 'interpolation', component: InterpolationComponent},
    {path: 'p-binding', component: PBindingComponent}
];
